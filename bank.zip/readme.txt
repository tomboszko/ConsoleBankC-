Simple bank account.

You can:

deposit
Withdraw
see account info + balance


PIN: 1234